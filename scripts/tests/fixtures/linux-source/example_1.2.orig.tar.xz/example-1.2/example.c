int example(void) { return 42; }
